/**
 * hust.cs.javacourse.search.query包里定义了和搜索有关的抽象类和接口.学生需要实现这些抽象类和接口的具体子类.
 */
package hust.cs.javacourse.search.query;