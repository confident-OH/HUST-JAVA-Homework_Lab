/**
 * 最后的程序运行入口类放在hust.cs.javacourse.search.run里
 */
package hust.cs.javacourse.search.run;