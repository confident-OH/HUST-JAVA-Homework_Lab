package homework.ch11_13.p2;

public class AchieveTask2 implements Task{
    @Override
    public void execute(){
        System.out.println("The second method implement Task.");
    }
}
