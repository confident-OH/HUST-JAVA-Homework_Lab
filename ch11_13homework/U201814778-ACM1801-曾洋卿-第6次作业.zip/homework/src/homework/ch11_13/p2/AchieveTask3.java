package homework.ch11_13.p2;

public class AchieveTask3 implements Task{
    @Override
    public void execute(){
        System.out.println("The third method implement Task.");
    }
}
